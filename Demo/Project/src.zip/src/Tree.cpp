#include "incl/Tree.h"
//add implementation here

void Tree::render(){

} 