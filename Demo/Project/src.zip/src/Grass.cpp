#include "incl/Grass.h"
//add implementation here

void Grass::render(){

}